# Evaluating whether AI can generate an animation-ready 3D game character from a single 2D concept image

## Authors
Amy Kate A. Carone  
Christian J. Loiselle

## Project Summary
This repository supports our CS208 Mini-PhD thesis on whether current AI systems can generate an animation-ready 3D game character from a single 2D concept-art image through an end-to-end pipeline.

The thesis evaluates four connected stages:
1. Concept art selection
2. 2D-to-3D mesh generation
3. Automatic rigging and skinning
4. Downstream animation testing

Our results show that current AI systems can generate plausible intermediate assets, but do not yet provide a dependable one-click path from concept art to a fully game-ready animated character.

## Repository Contents
- `thesis_paper.pdf` — final written thesis
- `concept_art_grading_with_charts(comparison).xlsx` — concept art evaluation data and charts
- `2D TO 3D MESH RESULTS.xlsx` — mesh-generation evaluation data and charts
- `rigged_models_tracking_remade_v2(1).xlsx` — rigging evaluation data and charts
- `figure_reproduction.md` — explanation of which files were used to generate which figures

## Reproducibility
All quantitative figures in the thesis were generated from the Excel workbooks included in this repository. Summary sheets and chart sheets inside those files were used to produce the figures shown in the final paper.

## Tools Used
- Microsoft Excel
- Microsoft Word
- TripoSR
- Tripo3D
- Mixamo
- ChatGPT

## Notes
Some tools used in the study were commercial or closed-source, so only the evaluation outputs and supporting analysis files are included here.
This repository is intended to satisfy the reproducibility requirement for the CS208 Mini-PhD project by providing the thesis, the source spreadsheets used for analysis, and instructions for reproducing the figures.
